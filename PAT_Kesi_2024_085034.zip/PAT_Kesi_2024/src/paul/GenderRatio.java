/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul;

/**
 *
 * @author paulk
 */
public class GenderRatio extends Variables
{

    public GenderRatio(Variables screenSocial, Variables screenEnviro, Variables screenEconom)
    {
        super(screenSocial, screenEnviro, screenEconom);
        toString();
    }

    //calculates the percent of the population which is female
    public double percentFemale()
    {
        return genderRatio / (genderRatio + 1) * 100;
    }

    //calculates the percent of the population which is male
    public double percentMale()
    {
        return 100 - percentFemale();
    }

    //calculates the amount of females in the population
    public double femalePop()
    {
        return (percentFemale() / 100) * population;
    }

    //calculates the amount of males in the population
    public double malePop()
    {
        return (percentMale() / 100) * population;
    }

    @Override
    public String toString()
    {
        return "\n\tFemale Population: " + deci.format(femalePop())
                + "\n\tMale Population: " + deci.format(malePop())
                + "\n\tPercentage Female: " + deci.format(percentFemale())
                + "\n\tPercentage Male: " + deci.format(percentMale());

    }

}
