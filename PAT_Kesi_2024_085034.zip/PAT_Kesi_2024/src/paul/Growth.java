/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul;

/**
 *
 * @author paulk
 */
public class Growth extends Variables
{

    int t;

    public Growth(Variables screenSocial, Variables screenEnviro, Variables screenEconom, int time)
    {
        super(screenSocial, screenEnviro, screenEconom);
        t = time;
    }

    //predicted GDP in a specified time period
    public double economicGrowth(int time)
    {
        return Math.pow(netGDP, time * economGrowth);
    }

    //predicted population in a specified time period
    public double populationGrowth(int time)
    {
        return 0.0 + population * (Math.pow(1 + growthRate, time)) + netMigration * time;
    }

    @Override
    public String toString()
    {
        return "\nEconomic Growth: " + deci.format(economicGrowth(t))
                + "\nPopulation Growth: " + deci.format(populationGrowth(t));
    }

}
