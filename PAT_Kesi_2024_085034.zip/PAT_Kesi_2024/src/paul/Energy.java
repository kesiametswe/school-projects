/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul;

/**
 *
 * @author paulk
 */
public class Energy extends Variables
{

    public Energy(Variables screenSocial, Variables screenEnviro, Variables screenEconom)
    {
        super(screenSocial, screenEnviro, screenEconom);
        toString();
    }

    //the average/estimated amount of energy/electricity each resident uses per year
    public double perPerson()
    {
        return energyConsumption / (energyReach * population);
    }

    //percent of total energy consumed which is generated from renewable sources
    public double percentRenewable()
    {
        return renewableEnergy / energyConsumption * 100;
    }

    @Override
    public String toString()
    {
        return "\n\tEnergy consumed per capita: "
                + deci.format(perPerson())
                + "kW"
                + "\n\tPercent of Renewable Energy used: "
                + deci.format(percentRenewable()) + "%";
    }

}
