/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul;

/**
 *
 * @author paulk
 */
public class PercentOfLand extends Variables
{

    public PercentOfLand(Variables screenSocial, Variables screenEnviro, Variables screenEconom)
    {
        super(screenSocial, screenEnviro, screenEconom);
        toString();
    }

    //percent of the total land area which is forestry
    public double percentForest()
    {
        return forestLand / totalLand * 100;
    }

    //percent of the total land area which is fertile for farming
    public double percentFertile()
    {
        return fertileLand / totalLand * 100;
    }

    //percent of the total land area which is dedicated to urban settlements
    public double percentUrban()
    {
        return urbanLand / totalLand * 100;
    }

    //percent of the total land area which is dedicated to rural settlements
    public double percentRural()
    {
        return ruralLand / totalLand * 100;
    }

    @Override
    public String toString()
    {
        return "\n\tUrban Settlements: " + deci.format(percentUrban()) + "%"
                + "\n\tRural Settlements: " + deci.format(percentRural()) + "%"
                + "\n\tFertile/Farming: " + deci.format(percentFertile()) + "%"
                + "\n\tForestry: " + deci.format(percentForest()) + "%";
    }

}
