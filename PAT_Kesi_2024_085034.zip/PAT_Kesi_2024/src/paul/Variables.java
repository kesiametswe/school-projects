/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul;

import java.text.DecimalFormat;

/**
 *
 * @author paulk
 */
public class Variables
{

    //Name of Area being analysed
    protected String areaName;

    //Development indicator: MEDC (1st world standard)/LEDC (3rd world standard)
    protected char economDevel; //'M' or 'L'

    //Of Land (all in sqkm)
    protected double totalLand;
    protected double fertileLand;
    protected double forestLand;
    protected double ruralLand;
    protected double urbanLand;

    //Of Climate
    protected double avePrecipitation; //mm, annually
    protected double aveTemperature; //degr celsius (year round)

    //Of Economics
    protected double dependencyRatio; //real num form (eg. dependents:workers = d/w)
    protected double netGDP; //USD
    protected double mediumIncome; //USD
    protected double economGrowth; // % growth in deci format (eg 20% = 0.2)

    //Of Energy
    protected double renewableEnergy; //kW
    protected double energyConsumption; // kW
    protected double energyReach; //percent of population that have access to electricity

    //Of Population (demographics)
    protected double genderRatio; //real num form (eg. female:male = f/m)
    protected int population; //whole num of people (<0)
    protected double growthRate; //% growth in deci format (eg 20% = 0.2)
    protected int netMigration; //whole num of people moving
    protected int urbanPopulation; //whole num of people
    protected int ruralPopulation;//whole num of people
//    protected double urbanGrowthRate; //percent growth 
//    protected double ruralGrowthRate; //percent growth 
    DecimalFormat deci = new DecimalFormat("#.00");

    //Logs in data from (Demographics) screen
    public Variables(String areaName, double genderRatio, int population, double growthRate, int netMigration, int urbanPopulation, int ruralPopulation)
    {
        this.areaName = areaName;
        this.genderRatio = genderRatio;
        this.population = population;
        this.growthRate = growthRate;
        this.netMigration = netMigration;
        this.urbanPopulation = urbanPopulation;
        this.ruralPopulation = ruralPopulation;

    }

    //Logs in data from (Environmental factors) screen
    public Variables(double totalLand, double fertileLand, double forestLand, double ruralLand, double urbanLand, double avePrecipitation, double aveTemperature)
    {
        this.totalLand = totalLand;
        this.fertileLand = fertileLand;
        this.forestLand = forestLand;
        this.ruralLand = ruralLand;
        this.urbanLand = urbanLand;
        this.avePrecipitation = avePrecipitation;
        this.aveTemperature = aveTemperature;

    }

    //Logs in data from(Economic Factors) screen
    public Variables(char economDevel, double dependencyRatio, double netGDP, double mediumIncome, double renewableEnergy, double energyConsumption, double energyReach, double economGrowth)
    {
        this.economDevel = economDevel;
        this.dependencyRatio = dependencyRatio;
        this.netGDP = netGDP;
        this.mediumIncome = mediumIncome;
        this.renewableEnergy = renewableEnergy;
        this.energyConsumption = energyConsumption;
        this.energyReach = energyReach;
        this.economGrowth = economGrowth;
    }

    //combines data from all screens for easy variable access in child classes
    public Variables(Variables screenSocial, Variables screenEnviro, Variables screenEconom)
    {
        this.areaName = screenSocial.areaName;
        this.genderRatio = screenSocial.genderRatio;
        this.population = screenSocial.population;
        this.growthRate = screenSocial.growthRate;
        this.netMigration = screenSocial.netMigration;
        this.urbanPopulation = screenSocial.urbanPopulation;
        this.ruralPopulation = screenSocial.ruralPopulation;

        this.totalLand = screenEnviro.totalLand;
        this.fertileLand = screenEnviro.fertileLand;
        this.forestLand = screenEnviro.forestLand;
        this.ruralLand = screenEnviro.ruralLand;
        this.urbanLand = screenEnviro.urbanLand;
        this.avePrecipitation = screenEnviro.avePrecipitation;
        this.aveTemperature = screenEnviro.aveTemperature;
        this.economGrowth = screenEnviro.economGrowth;

        this.economDevel = screenEconom.economDevel;
        this.dependencyRatio = screenEconom.dependencyRatio;
        this.netGDP = screenEconom.netGDP;
        this.mediumIncome = screenEconom.mediumIncome;
        this.renewableEnergy = screenEconom.renewableEnergy;
        this.energyConsumption = screenEconom.energyConsumption;
        this.energyReach = screenEconom.energyReach;

    }

    public Variables()
    {
    }

    public String getAreaName()
    {
        return areaName;
    }

    public char getEconomDevel()
    {
        return economDevel;
    }

    public double getTotalLand()
    {
        return totalLand;
    }

    public double getFertileLand()
    {
        return fertileLand;
    }

    public double getForestLand()
    {
        return forestLand;
    }

    public double getRuralLand()
    {
        return ruralLand;
    }

    public double getUrbanLand()
    {
        return urbanLand;
    }

    public double getAvePrecipitation()
    {
        return avePrecipitation;
    }

    public double getAveTemperature()
    {
        return aveTemperature;
    }

    public double getDependencyRatio()
    {
        return dependencyRatio;
    }

    public double getNetGDP()
    {
        return netGDP;
    }

    public double getMediumIncome()
    {
        return mediumIncome;
    }

    public double getEconomGrowth()
    {
        return economGrowth;
    }

    public double getRenewableEnergy()
    {
        return renewableEnergy;
    }

    public double getEnergyConsumption()
    {
        return energyConsumption;
    }

    public double getEnergyReach()
    {
        return energyReach;
    }

    public double getGenderRatio()
    {
        return genderRatio;
    }

    public void setAreaName(String areaName)
    {
        this.areaName = areaName;
    }

    public void setEconomDevel(char economDevel)
    {
        this.economDevel = economDevel;
    }

    public void setTotalLand(double totalLand)
    {
        this.totalLand = totalLand;
    }

    public void setFertileLand(double fertileLand)
    {
        this.fertileLand = fertileLand;
    }

    public void setForestLand(double forestLand)
    {
        this.forestLand = forestLand;
    }

    public void setRuralLand(double ruralLand)
    {
        this.ruralLand = ruralLand;
    }

    public void setUrbanLand(double urbanLand)
    {
        this.urbanLand = urbanLand;
    }

    public void setAvePrecipitation(double avePrecipitation)
    {
        this.avePrecipitation = avePrecipitation;
    }

    public void setAveTemperature(double aveTemperature)
    {
        this.aveTemperature = aveTemperature;
    }

    public void setDependencyRatio(double dependencyRatio)
    {
        this.dependencyRatio = dependencyRatio;
    }

    public void setNetGDP(double netGDP)
    {
        this.netGDP = netGDP;
    }

    public void setMediumIncome(double mediumIncome)
    {
        this.mediumIncome = mediumIncome;
    }

    public void setEconomGrowth(double economGrowth)
    {
        this.economGrowth = economGrowth;
    }

    public void setRenewableEnergy(double renewableEnergy)
    {
        this.renewableEnergy = renewableEnergy;
    }

    public void setEnergyConsumption(double energyConsumption)
    {
        this.energyConsumption = energyConsumption;
    }

    public void setEnergyReach(double energyReach)
    {
        this.energyReach = energyReach;
    }

    public void setGenderRatio(double genderRatio)
    {
        this.genderRatio = genderRatio;
    }

    public void setPopulation(int population)
    {
        this.population = population;
    }

    public void setGrowthRate(double growthRate)
    {
        this.growthRate = growthRate;
    }

    public void setNetMigration(int netMigration)
    {
        this.netMigration = netMigration;
    }

    public void setUrbanPopulation(int urbanPopulation)
    {
        this.urbanPopulation = urbanPopulation;
    }

    public void setRuralPopulation(int ruralPopulation)
    {
        this.ruralPopulation = ruralPopulation;
    }

    public int getPopulation()
    {
        return population;
    }

    public double getGrowthRate()
    {
        return growthRate;
    }

    public int getNetMigration()
    {
        return netMigration;
    }

    public int getUrbanPopulation()
    {
        return urbanPopulation;
    }

    public int getRuralPopulation()
    {
        return ruralPopulation;
    }

}
