/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul;

/**
 *
 * @author paulk
 */
public class MoneyPerCapita extends Variables
{

    public MoneyPerCapita(Variables screenSocial, Variables screenEnviro, Variables screenEconom)
    {
        super(screenSocial, screenEnviro, screenEconom);
        toString();
    }

    //the amount of money per capita
    public double perCapita()
    {
        return netGDP / population;
    }

    @Override
    public String toString()
    {
        return "\n\tGDP per Capita: R" + deci.format(perCapita());
    }

}
